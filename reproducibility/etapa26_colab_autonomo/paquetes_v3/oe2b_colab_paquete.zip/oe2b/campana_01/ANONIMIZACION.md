# Anonimización de seis archivos de OE2-B

Por privacidad, las copias públicas de seis archivos de la campaña del componente por HTTP del segundo objetivo (cinco registros de Locust y el registro de intentos) tienen sustituidos, con la misma longitud, el nombre del equipo y el usuario de Windows de las rutas temporales por valores neutros (`HOST001` y `USER`). No se alteró ninguna marca de tiempo, métrica, código HTTP ni identificador experimental. La lista con las sumas SHA-256 original y anonimizada de cada archivo está en `anonimizacion_oe2b.json`; los cuadernos comparan estos seis archivos con la suma anonimizada y todos los demás con la suma original de la campaña. Los análisis no leen estos archivos.


## Segunda pasada (v2)

En el campo `error` de cinco intentos de `intentos.jsonl` (los de la salida 1 de Locust) quedaban rutas locales truncadas (carpeta de curso, carpeta de trabajo y ruta temporal de una herramienta). Se sustituyeron por `<RUTA_LOCAL_ANONIMIZADA>`. No se cambió ningún otro campo; el análisis no lee ese campo. La suma anonimizada actual figura en `anonimizacion_oe2b.json` (`sha256_anonimizado`; la de la primera pasada, en `sha256_anonimizado_v1`).
